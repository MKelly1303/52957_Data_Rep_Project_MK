mysql ={
	'host':"localhost",
	'username':"root",
	'password':"root",
	'database':"patientdb"
}